#include "module2.h"
#include "ui_module2.h"

module2::module2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::module2)
{
    ui->setupUi(this);
}

module2::~module2()
{
    delete ui;
}

void module2::on_horizontalSlider_valueChanged(int value)
{
    ui->label->setText(QString::number(value));
}

QString module2::getLineText(){
    return lineText;
}

void module2::on_buttonBox_accepted()
{
    lineText = ui->label->text();
}


void module2::on_buttonBox_rejected()
{

}

