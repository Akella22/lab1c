#include "module1.h"
#include "ui_module1.h"

module1::module1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::module1)
{
    ui->setupUi(this);
}

module1::~module1()
{
    delete ui;
}

void module1::on_buttonBox_accepted()
{
    lineText = ui->lineEdit->text();
}

QString module1::getLineText(){
    return lineText;
}

void module1::on_buttonBox_rejected()
{

}

