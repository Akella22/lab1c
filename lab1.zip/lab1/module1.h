#ifndef MODULE1_H
#define MODULE1_H

#include <QDialog>

namespace Ui {
class module1;
}

class module1 : public QDialog
{
    Q_OBJECT

public:
    explicit module1(QWidget *parent = nullptr);
    QString getLineText();
    ~module1();

private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::module1 *ui;
    QString lineText;
};

#endif // MODULE1_H
