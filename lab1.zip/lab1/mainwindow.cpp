#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "module1.h"
#include "module2.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionwork_1_triggered()
{
    module1 work;
    work.setModal(true);
    work.exec();

    if(work.getLineText() != ""){
        ui->label->setText(work.getLineText());
    }
}


void MainWindow::on_actionwork_2_triggered()
{
    module2 work;
    work.setModal(true);
    work.exec();

    if(work.getLineText() != ""){
        ui->label->setText(work.getLineText());
    }
}

