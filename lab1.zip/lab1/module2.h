#ifndef MODULE2_H
#define MODULE2_H

#include <QDialog>

namespace Ui {
class module2;
}

class module2 : public QDialog
{
    Q_OBJECT

public:
    explicit module2(QWidget *parent = nullptr);
    QString getLineText();
    ~module2();

private slots:
    void on_horizontalSlider_valueChanged(int value);

    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    QString lineText;
    Ui::module2 *ui;
};

#endif // MODULE2_H
